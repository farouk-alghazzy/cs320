import pandas as pd
from flask import Flask, request, Response, jsonify
import json
import re
import time
import matplotlib.pyplot as plt
import matplotlib
import io
matplotlib.use('Agg')

# Dataset from https://data-cityofmadison.opendata.arcgis.com/datasets/1b4a7d2e3cd94218a28d4ed8ee91d225_4/explore?location=43.082971%2C-89.409150%2C12.35

app = Flask(__name__)
df = pd.read_csv("main.csv")
ip_dict = {}

home_visits = 0
def count_visit():
    global home_visits
    home_visits += 1

num_subscribed = 0
def increment_subscriber_count():
    global num_subscribed
    num_subscribed += 1    

click_thru_a = 0
click_thru_b = 0

@app.route('/')
def home():
    count_visit()
    if home_visits <= 10:
        template = "index1.html" if (home_visits % 2) == 0 else "index2.html"
        color = "lightyellow" if (home_visits % 2) == 0 else "lightblue"
        with open(template) as f:
            html = f.read()
        return f"""<html><body style="background-color:{color}">{html}"""

    template = "index1.html" if click_thru_a > click_thru_b else "index2.html"
    color = "lightyellow" if click_thru_a > click_thru_b else "lightblue"
    with open(template) as f:
        html = f.read()
    return f"""<html><body style="background-color:{color}">{html}"""

@app.route("/dashboard_1.svg")
def dashboard_1():  
    bins = int(request.args.get("bins", 10))
    fig, ax = plt.subplots(figsize=(15, 5))
    df.hist(ax=ax, bins=bins, column='X')
    plt.title("X-Coordinates of Polling Sites in Dane County")
    plt.xlabel("Range of x-coordinates")
    plt.ylabel("Frequency")
    plt.tight_layout()
    f = io.StringIO() 
    fig.savefig(f, format="svg")
    plt.close()
    return Response(f.getvalue(), headers={"Content-Type": "image/svg+xml"})
            
@app.route("/dashboard_2.svg")
def dashboard_2():
    fig, ax = plt.subplots(figsize=(21, 7))
    df["tvpoll_p_WARD"].plot.bar(ax=ax)
    ax.set_title("Ward #s of Polling Sites in Dane County")
    ax.set_xlabel("Ward # (X-Axis)")
    ax.set_ylabel("Ward # (Y-Axis)")
    plt.tight_layout()
    f = io.StringIO() 
    fig.savefig(f, format="svg")
    plt.close()
    return Response(f.getvalue(), headers={"Content-Type": "image/svg+xml"})

@app.route('/email', methods=["POST"])
def email():
    email = str(request.data, "utf-8")
    if re.match(r"^[A-Za-z0-9]+[\._]?[A-Za-z0-9]+[@]\w+[.]\w{2,3}$", email):
        increment_subscriber_count()
        with open("emails.txt", "a") as f:
            f.write(email + "\n") 
        return jsonify(f"Thanks, your subscriber number is {num_subscribed}!")
    return jsonify(f"Oops, invalid email!")

@app.route('/browse.html')
def browse():
    with open("browse.html") as f:
        html_file = df.to_html()
    return "<h1>Browse</h1>" + html_file

@app.route('/browse.json')
def browse_json():
    browse_json = jsonify(df.to_dict("records")) 
    ip_address = request.remote_addr
    if ip_address not in ip_dict:
        curr_time = time.time()
        ip_dict[ip_address] = curr_time
        return browse_json
    curr_time = time.time()
    if curr_time - ip_dict[ip_address] > 60:
        ip_dict[ip_address] = curr_time
        return browse_json
    return Response("<b>Go away</b>", status=429, headers={"Retry-After": "60 seconds"})

@app.route('/visitors.json')
def visitors_json():
    return jsonify(ip_dict)

@app.route("/donate.html")
def donate():
    global click_thru_a
    global click_thru_b
    if "from" in request.args:
        version = request.args['from']
        if version == "A":
            click_thru_a += 1
        else:
            click_thru_b += 1
    return """<html><body>
              <h1>Donations</h1>
              Please make one, it will help democracy greatly!
              </body></html>"""

if __name__ == '__main__':
    app.run(host="0.0.0.0", debug=True, threaded=False) # don't change this line!

    
   
