import re
import netaddr
import csv
from bisect import bisect
import pandas as pd

def lookup_region(ip):
    ip_addr = re.sub(r"[^\d.]", "0", ip)
    ip_addr = int(netaddr.IPAddress(ip_addr))
    df = pd.read_csv('ip2location.csv')
    idx = bisect(df['low'], ip_addr)
    return df['region'][idx - 1]

class Filing:
    def __init__(self, html):
        self.dates = re.findall(r"\b\d{4}-\d{2}-\d{2}\b|\d{4}-\d{2}-\d{2}(?=\W)", html, re.DOTALL)
        self.sic = re.findall(r"SIC\s*=\s*\"?(\d+)\"?", html, re.DOTALL)
        if len(self.sic) > 0:
            self.sic = int(self.sic[0])
        else: 
            self.sic = None
        self.addresses = [
            '\n'.join([line.strip() for line in re.findall(r'<span class="mailerAddress">(.*?)</span>', addr_html, re.DOTALL) if line.strip()])
            for addr_html in re.findall(r'<div class="mailer">([\s\S]+?)</div>?', html)
        ] 
        self.addresses = [address for address in self.addresses if address]
    def state(self):
        for address in self.addresses:
            match = re.search(r"\b([A-Z]{2})\s*(\d{5})\b", address)
            if match:
                return match.group(1)
        return None
        